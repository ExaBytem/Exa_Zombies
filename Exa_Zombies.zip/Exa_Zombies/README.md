# Exa_Zombies
This is a zombie Script, complemented with ESX
* Zombies Have Sound!!
* You Can Mute And Unmute Zombies Sound With /mutezombies
* Loot from zombies (Weapons, items and money)
* Loot probability
* Follow the closest player
* Hordes
* Zombie attack proximity
* Safe Zones
* Loot Objects

## How install
1. Download the github repository
2. Drop the files in your [resource] folder
3. Don't forget add ensure Exa_Zombies in your server.cfg file
4. Configure to your liking

## Screenshots
![Image description](https://i.imgur.com/D5DvLeg.png)
